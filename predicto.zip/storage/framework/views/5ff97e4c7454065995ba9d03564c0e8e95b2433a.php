     <!-- Footer  -->
     <footer>
       <div class="info">
         <a href="/tips.html">Today match prediction</a>
       </div>
     </footer>