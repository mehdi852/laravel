 
<?php $__env->startSection('content'); ?>
<a href="<?php echo e(url('/')); ?>">
        <div class="mobileBack">
         <img  alt="back" src="<?php echo e(asset('img/back.svg')); ?>">
        </div>
      </a>
<div class="tips">
        <div class="left">
          <ul>
            <?php $__currentLoopData = $Categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><img class="flag" alt="<?php echo e($cat->country); ?>" src=" <?php echo e(asset('img/'. $cat->country .'.png')); ?> "><a href="/tips/<?php echo e($cat->country); ?>"><?php echo e($cat->name); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


          </ul>
        </div>
        <div class="right">
          <div class="tips-heading">
            Available Matches 
          </div>
          <div class="tips-List">
             <ul>
               <?php $__currentLoopData = $Matches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <li><a href="<?php echo e(url('tips/'.  str_replace(' ', '-', $match->hometeam).'/'. str_replace(' ', '-', $match->awayteam).'/'.$match->id)); ?>"><?php echo e($match->hometeam); ?> <span class="dash">-</span> <?php echo e($match->awayteam); ?> 
               
               <span class=" volume green"><?php echo e($match->risk); ?> </span>

                          <?php if($match->risk === 'high'): ?>
                          <span class=" volume red"><?php echo e($match->risk); ?> </span>
                          
                          <?php elseif($match->risk === 'medium'): ?>
                          <span class=" volume orange"><?php echo e($match->risk); ?> </span>
                          <?php elseif($match->risk === 'low'): ?>
                          <span class=" volume green"><?php echo e($match->risk); ?> </span>
                          <?php endif; ?>
              </a></li>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
             </ul>
          </div>
          <div class="notice">
                 <span>Notice</span> : matches are picked manually from experts.
           </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>