    <!-- Navbar-->
    <div class="navbar">
      <div class="brand"><a><img alt="logo" src="<?php echo e(asset('img/logo.png')); ?>"></a></div>

      <?php if(Route::current()->getName() != 'home'): ?>
      <div class="menu">
        <a href="<?php echo e(url('tips/spain')); ?>" class="btn"> Go back</a>
      </div>
      <?php endif; ?>
  
    </div>
    <div class="clearfix"></div>

