 
<?php $__env->startSection('content'); ?>
 <a href="<?php echo e(url('tips/spain')); ?>">
    <div class="mobileBack">
     <img  alt="back" src="<?php echo e(asset('img/back.svg')); ?>">
    </div>
  </a>

  <div class="wrapper">
      <!--home-->
      <div class="home">

                    <?php if($Match->homepercent >= 60): ?>
                    <div class="circle border-green"><span><?php echo e($Match->homepercent); ?>% </span></div>
                          <?php elseif($Match->homepercent >= 40 && $Match->homepercent < 60   ): ?>
                          <div class="circle border-orange"><span><?php echo e($Match->homepercent); ?>% </span></div>
                          <?php elseif($Match->homepercent <= 40): ?>
                          <div class="circle border-red"><span><?php echo e($Match->homepercent); ?>% </span></div>
                          <?php endif; ?>

        <button class="btn-default"><?php echo e($Match->hometeam); ?></button>
        <div class="stats-page">

 
                          <?php if($Match->homeposession === 'big'): ?>
                        <div class="progress green <?php echo e($Match->homeposession); ?>  thin"> Possesion</div>                          
                          <?php elseif($Match->homeposession === 'medium'): ?>
                          <div class="progress orange <?php echo e($Match->homeposession); ?>  thin"> Possesion</div>                          
                          <?php elseif($Match->homeposession=== 'small'): ?>
                          <div class="progress red <?php echo e($Match->homeposession); ?>  thin"> Possesion</div>                          
                          <?php endif; ?>

                          <?php if($Match->homeattack === 'big'): ?>
                          <div class="progress green <?php echo e($Match->homeattack); ?> thin">Attack</div>                         
                          <?php elseif($Match->homeattack === 'medium'): ?>
                          <div class="progress orange <?php echo e($Match->homeattack); ?> thin">Attack</div>                         
                          <?php elseif($Match->homeattack === 'small'): ?>
                          <div class="progress red <?php echo e($Match->homeattack); ?> thin">Attack</div>                         
                          <?php endif; ?>

                          <?php if($Match->homedefence === 'big'): ?>
                          <div class="progress green <?php echo e($Match->homedefence); ?> thin">Defence</div>                         
                          <?php elseif($Match->homedefence === 'medium'): ?>
                          <div class="progress orange <?php echo e($Match->homedefence); ?> thin">Defence</div>                        
                          <?php elseif($Match->homedefence=== 'small'): ?>
                          <div class="progress red <?php echo e($Match->homedefence); ?> thin">Defence</div>                         
                          <?php endif; ?>

        </div>
        <div class="history">
          <span> Last 5 games </span>
          <ul>

                      <?php for($i = 0; $i < 5; $i++): ?>
                      <?php if( $Match->homelastgames[$i] === 'W'): ?>
                      <li class="green"><?php echo e($Match->homelastgames[$i]); ?></li>
                       <?php elseif($Match->homelastgames[$i] === 'D'): ?>
                       <li class="grey"><?php echo e($Match->homelastgames[$i]); ?></li>
                          <?php elseif($Match->homelastgames[$i] === 'L'): ?>
                          <li class="red"><?php echo e($Match->homelastgames[$i]); ?></li>
                          <?php endif; ?>
                      <?php endfor; ?>
  
          </ul>
        </div>
        <div class="content">
          <div class="content-item">
            <span> Goals per game : </span> <span><?php echo e($Match->homegoals); ?></span>
          </div>
          <div class="content-item">
            <span> Avg Possession: </span> <span><?php echo e($Match->homeAvgPossesion); ?></span>
          </div>
          <div class="content-item">
            <span> Pass Accuracy: </span> <span><?php echo e($Match->homePassAccuracy); ?></span>
          </div>
        </div>
      </div>
       <!--middle-->
      <div class="middle">
        <span class="league"><?php echo e($Match->category); ?></span>
        <div class="table">
            <table>
                <tr>
                  <th><?php echo e($Match->homerank); ?></th>
                  <th><?php echo e($Match->hometeam); ?></th>
                  <th><?php echo e($Match->homepoints); ?> Pts</th>
                </tr>
                <tr>
                    <th><?php echo e($Match->awayrank); ?></th>
                    <th><?php echo e($Match->awayteam); ?></th>
                    <th><?php echo e($Match->awaypoints); ?> Pts</th>
                  </tr>
              </table>
        </div>
        <span class="league">Tips</span>
        <div class="moreInfo">
            <ul>
              <li><?php echo e($Match->generaltips); ?></li>
        
            </ul>
        </div>
        
      </div>

      <!--away-->
      <div class="home">

      <?php if($Match->awaypercent >= 60): ?>
                    <div class="circle border-green"><span><?php echo e($Match->awaypercent); ?>% </span></div>
                          <?php elseif($Match->awaypercent >= 40 && $Match->awaypercent < 60   ): ?>
                          <div class="circle border-orange"><span><?php echo e($Match->awaypercent); ?>% </span></div>
                          <?php elseif($Match->awaypercent <= 40): ?>
                          <div class="circle border-red"><span><?php echo e($Match->awaypercent); ?>% </span></div>
                          <?php endif; ?>
                          

        <button class="btn-default"><?php echo e($Match->awayteam); ?></button>
        <div class="stats-page">

 
                          <?php if($Match->awayposession === 'big'): ?>
                        <div class="progress green <?php echo e($Match->awayposession); ?>  thin"> Possesion</div>                          
                          <?php elseif($Match->awayposession === 'medium'): ?>
                          <div class="progress orange <?php echo e($Match->awayposession); ?>  thin"> Possesion</div>                          
                          <?php elseif($Match->awayposession=== 'small'): ?>
                          <div class="progress red <?php echo e($Match->awayposession); ?>  thin"> Possesion</div>                          
                          <?php endif; ?>

                          <?php if($Match->awayattack === 'big'): ?>
                          <div class="progress green <?php echo e($Match->awayattack); ?> thin">Attack</div>                         
                          <?php elseif($Match->awayattack === 'medium'): ?>
                          <div class="progress orange <?php echo e($Match->awayattack); ?> thin">Attack</div>                         
                          <?php elseif($Match->awayattack=== 'small'): ?>
                          <div class="progress red <?php echo e($Match->awayattack); ?> thin">Attack</div>                         
                          <?php endif; ?>

                          <?php if($Match->awaydefence === 'big'): ?>
                          <div class="progress green { $Match->awaydefence }} thin">Defence</div>                         
                          <?php elseif($Match->awaydefence === 'medium'): ?>
                          <div class="progress orange <?php echo e($Match->awaydefence); ?> thin">Defence</div>                        
                          <?php elseif($Match->awaydefence === 'small'): ?>
                          <div class="progress red <?php echo e($Match->awaydefence); ?> thin">Defence</div>                         
                          <?php endif; ?>

        </div>
        <div class="history">
          <span> Last 5 games </span>
          <ul>

                      <?php for($i = 0; $i < 5; $i++): ?>
                      <?php if( $Match->awaylastgames[$i] === 'W'): ?>
                      <li class="green"><?php echo e($Match->awaylastgames[$i]); ?></li>
                       <?php elseif($Match->awaylastgames[$i] === 'D'): ?>
                       <li class="grey"><?php echo e($Match->awaylastgames[$i]); ?></li>
                          <?php elseif($Match->awaylastgames[$i] === 'L'): ?>
                          <li class="red"><?php echo e($Match->awaylastgames[$i]); ?></li>
                          <?php endif; ?>
                      <?php endfor; ?>
  
          </ul>
        </div>
        <div class="content">
          <div class="content-item">
            <span> Goals per game : </span> <span><?php echo e($Match->awaygoals); ?></span>
          </div>
          <div class="content-item">
            <span> Avg Possession: </span> <span><?php echo e($Match->awayAvgPossesion); ?></span>
          </div>
          <div class="content-item">
            <span> Pass Accuracy: </span> <span><?php echo e($Match->awayPassAccuracy); ?></span>
          </div>
        </div>
      </div>
         <!-- Footer  -->
   
    </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>